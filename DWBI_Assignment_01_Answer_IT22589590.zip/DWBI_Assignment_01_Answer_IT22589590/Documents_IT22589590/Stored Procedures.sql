-- Stored Procedure for DimMedicineCatg
CREATE PROCEDURE dbo.UpdateDimMedicineCatg
@Med_Catg_Code int,
@BrandName nvarchar(50),
@CompanyName nvarchar(50),
@ModifiedDate datetime
AS
BEGIN
    if not exists (select MedicineCatgSK
                  from dbo.DimMedicineCatg
                  where AlternateMedicineCatgID = @Med_Catg_Code)
    BEGIN
        insert into dbo.DimMedicineCatg
        (AlternateMedicineCatgID, BrandName, CompanyName, SrcModifiedDate, InsertDate, ModifiedDate)
        values
        (@Med_Catg_Code, @BrandName, @CompanyName, @ModifiedDate, GETDATE(), GETDATE())
    END;
    
    if exists (select MedicineCatgSK
              from dbo.DimMedicineCatg
              where AlternateMedicineCatgID = @Med_Catg_Code)
    BEGIN
        update dbo.DimMedicineCatg
        set BrandName = @BrandName,
            CompanyName = @CompanyName,
            SrcModifiedDate = @ModifiedDate,
            ModifiedDate = GETDATE()
        where AlternateMedicineCatgID = @Med_Catg_Code
    END;
END;
GO

-- Stored Procedure for DimMedicineSubCatg
CREATE PROCEDURE dbo.UpdateDimMedicineSubCatg
@Med_Sub_Ref_No int,
@MedicineCatgKey int,
@Name nvarchar(400),
@ManufactDate datetime,
@ExpiryDate datetime,
@ModifiedDate datetime
AS
BEGIN
    if not exists (select MedicineSubCatgSK
                  from dbo.DimMedicineSubCatg
                  where AlternateMedicineSubCatgID = @Med_Sub_Ref_No)
    BEGIN
        insert into dbo.DimMedicineSubCatg
        (AlternateMedicineSubCatgID, MedicineCatgKey, SubCatgName, ManufactureDate, ExpiryDate, 
         SrcModifiedDate, InsertDate, ModifiedDate)
        values
        (@Med_Sub_Ref_No, @MedicineCatgKey, @Name, @ManufactDate, @ExpiryDate, 
         @ModifiedDate, GETDATE(), GETDATE())
    END;
    
    if exists (select MedicineSubCatgSK
              from dbo.DimMedicineSubCatg
              where AlternateMedicineSubCatgID = @Med_Sub_Ref_No)
    BEGIN
        update dbo.DimMedicineSubCatg
        set MedicineCatgKey = @MedicineCatgKey,
            SubCatgName = @Name,
            ManufactureDate = @ManufactDate,
            ExpiryDate = @ExpiryDate,
            SrcModifiedDate = @ModifiedDate,
            ModifiedDate = GETDATE()
        where AlternateMedicineSubCatgID = @Med_Sub_Ref_No
    END;
END;
GO

-- Stored Procedure for DimRoom
CREATE PROCEDURE dbo.UpdateDimRoom
@Room_ID int,
@Room_Type nvarchar(50),
@Location nvarchar(50),
@No_Of_Beds int,
@No_Of_Chairs int,
@Ward_Charge float
AS
BEGIN
    IF NOT EXISTS (SELECT RoomSK
                  FROM dbo.DimRoom
                  WHERE AlternateRoomID = @Room_ID)
    BEGIN
        INSERT INTO dbo.DimRoom
        (AlternateRoomID, RoomType, Location, NumberOfBeds, NumberOfChairs, WardCharge, InsertDate, ModifiedDate)
        VALUES
        (@Room_ID, @Room_Type, @Location, @No_Of_Beds, @No_Of_Chairs, @Ward_Charge, GETDATE(), GETDATE())
    END;
    
    IF EXISTS (SELECT RoomSK
              FROM dbo.DimRoom
              WHERE AlternateRoomID = @Room_ID)
    BEGIN
        UPDATE dbo.DimRoom
        SET RoomType = @Room_Type,
            Location = @Location,
            NumberOfBeds = @No_Of_Beds,
            NumberOfChairs = @No_Of_Chairs,
            WardCharge = @Ward_Charge,
            ModifiedDate = GETDATE()
        WHERE AlternateRoomID = @Room_ID
    END;
END;
GO

-- Stored Procedure for DimEmployee
CREATE PROCEDURE dbo.UpdateDimEmployee
@Employee_ID int,
@Employee_Name nvarchar(255),
@Email nvarchar(255),
@Sex nvarchar(255),
@Salary float,
@ContactNo int,
@Role nvarchar(255)
AS
BEGIN
    IF NOT EXISTS (SELECT EmployeeSK
                  FROM dbo.DimEmployee
                  WHERE AlternateEmployeeID = @Employee_ID)
    BEGIN
        INSERT INTO dbo.DimEmployee
        (AlternateEmployeeID, EmployeeName, Email, Gender, Salary, ContactNumber, Role, InsertDate, ModifiedDate)
        VALUES
        (@Employee_ID, @Employee_Name, @Email, @Sex, @Salary, @ContactNo, @Role, GETDATE(), GETDATE())
    END;
    
    IF EXISTS (SELECT EmployeeSK
              FROM dbo.DimEmployee
              WHERE AlternateEmployeeID = @Employee_ID)
    BEGIN
        UPDATE dbo.DimEmployee
        SET EmployeeName = @Employee_Name,
            Email = @Email,
            Gender = @Sex,
            Salary = @Salary,
            ContactNumber = @ContactNo,
            Role = @Role,
            ModifiedDate = GETDATE()
        WHERE AlternateEmployeeID = @Employee_ID
    END;
END;
GO

-- Stored Procedure for SCD Type 2 handling of Patient data
CREATE PROCEDURE dbo.UpdateDimPatient
@Patient_ID int,
@Patient_Name nvarchar(255),
@Gender nvarchar(255),
@Phone_Number nvarchar(255),
@Email nvarchar(255),
@Address nvarchar(50),
@City nvarchar(50),
@Country nvarchar(50)
AS
BEGIN
    -- First, check if the patient exists
    IF NOT EXISTS (SELECT 1 FROM dbo.DimPatient WHERE AlternatePatientID = @Patient_ID)
    BEGIN
        -- Patient doesn't exist, insert new record
        INSERT INTO dbo.DimPatient
        (AlternatePatientID, PatientName, Gender, PhoneNumber, Email, 
         Address, City, Country, StartDate, EndDate, IsCurrent, InsertDate, ModifiedDate)
        VALUES
        (@Patient_ID, @Patient_Name, @Gender, @Phone_Number, @Email,
         @Address, @City, @Country, GETDATE(), NULL, 1, GETDATE(), GETDATE())
    END
    ELSE
    BEGIN
        -- Patient exists, check if address attributes changed (Type 2 attributes)
        IF EXISTS (SELECT 1 FROM dbo.DimPatient 
                  WHERE AlternatePatientID = @Patient_ID 
                  AND IsCurrent = 1
                  AND (Address != @Address OR City != @City OR Country != @Country))
        BEGIN
            -- Address info changed, expire current record
            UPDATE dbo.DimPatient
            SET EndDate = GETDATE(),
                IsCurrent = 0,
                ModifiedDate = GETDATE()
            WHERE AlternatePatientID = @Patient_ID
            AND IsCurrent = 1;
            
            -- Insert new record with updated address info
            INSERT INTO dbo.DimPatient
            (AlternatePatientID, PatientName, Gender, PhoneNumber, Email, 
             Address, City, Country, StartDate, EndDate, IsCurrent, InsertDate, ModifiedDate)
            VALUES
            (@Patient_ID, @Patient_Name, @Gender, @Phone_Number, @Email,
             @Address, @City, @Country, GETDATE(), NULL, 1, GETDATE(), GETDATE());
        END
        ELSE
        BEGIN
            -- Type 1 attributes may have changed (phone, email), update them
            UPDATE dbo.DimPatient
            SET PhoneNumber = @Phone_Number,
                Email = @Email,
                PatientName = @Patient_Name,
                Gender = @Gender,
                ModifiedDate = GETDATE()
            WHERE AlternatePatientID = @Patient_ID
            AND IsCurrent = 1;
        END
    END
END;
GO

-- Stored Procedure for DimMedication
CREATE PROCEDURE dbo.UpdateDimMedication
@Med_Code int,
@Med_Name nvarchar(50),
@Quantity int,
@Price float,
@Patient_ID nvarchar(50),
@MedicineSubCatgKey int
AS
BEGIN
    IF NOT EXISTS (SELECT MedicationSK
                  FROM dbo.DimMedication
                  WHERE AlternateMedicationID = @Med_Code)
    BEGIN
        INSERT INTO dbo.DimMedication
        (AlternateMedicationID, MedicationName, Quantity, Price, PatientID, MedicineSubCatgKey, InsertDate, ModifiedDate)
        VALUES
        (@Med_Code, @Med_Name, @Quantity, @Price, @Patient_ID, @MedicineSubCatgKey, GETDATE(), GETDATE())
    END;
    
    IF EXISTS (SELECT MedicationSK
              FROM dbo.DimMedication
              WHERE AlternateMedicationID = @Med_Code)
    BEGIN
        UPDATE dbo.DimMedication
        SET MedicationName = @Med_Name,
            Quantity = @Quantity,
            Price = @Price,
            PatientID = @Patient_ID,
            MedicineSubCatgKey = @MedicineSubCatgKey,
            ModifiedDate = GETDATE()
        WHERE AlternateMedicationID = @Med_Code
    END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.PopulateDateDimension
AS
BEGIN
    -- No need to implement this procedure as the DimDate table 
    -- already has a comprehensive population script in the table creation file
    -- The existing code block in the table definition handles this functionality
    
    PRINT 'DimDate is already populated through the table creation script';
    RETURN;
END;
GO

-- Stored Procedure for FactRecord
CREATE OR ALTER PROCEDURE dbo.InsertFactRecord
@Record_ID int,
@PatientKey int,
@RoomKey int,
@Age int,
@Treatment_Start_Date datetime,
@Treatment_End_Date datetime,
@Response nvarchar(50),
@Description nvarchar(250),
@TreatmentStartDateKey int = NULL,
@TreatmentEndDateKey int = NULL
AS
BEGIN
    -- Auto-resolve DateKeys if not provided
    IF @TreatmentStartDateKey IS NULL AND @Treatment_Start_Date IS NOT NULL
        SELECT @TreatmentStartDateKey = DateKey 
        FROM dbo.DimDate 
        WHERE [Date] = CAST(@Treatment_Start_Date AS DATE);
    
    IF @TreatmentEndDateKey IS NULL AND @Treatment_End_Date IS NOT NULL
        SELECT @TreatmentEndDateKey = DateKey 
        FROM dbo.DimDate 
        WHERE [Date] = CAST(@Treatment_End_Date AS DATE);
    
    -- Calculate treatment duration in days
    DECLARE @TreatmentDuration INT = NULL;
    IF @Treatment_Start_Date IS NOT NULL AND @Treatment_End_Date IS NOT NULL
        SET @TreatmentDuration = DATEDIFF(DAY, @Treatment_Start_Date, @Treatment_End_Date);
    
    -- Current timestamp for accm_txn_create_time
    DECLARE @CurrentTime DATETIME = GETDATE();
    
    -- Check if record already exists
    IF NOT EXISTS (SELECT 1 FROM dbo.FactRecord WHERE RecordID = @Record_ID)
    BEGIN
        INSERT INTO dbo.FactRecord
        (RecordID, PatientKey, RoomKey, TreatmentStartDateKey, TreatmentEndDateKey,
         TreatmentStartDate, TreatmentEndDate, Age, Response, Description, 
         TreatmentDuration, InsertDate, accm_txn_create_time)
        VALUES
        (@Record_ID, @PatientKey, @RoomKey, @TreatmentStartDateKey, @TreatmentEndDateKey,
         @Treatment_Start_Date, @Treatment_End_Date, @Age, @Response, @Description,
         @TreatmentDuration, @CurrentTime, @CurrentTime)
    END
    ELSE
    BEGIN
        -- Update existing record but do NOT update accm_txn_create_time
        UPDATE dbo.FactRecord
        SET PatientKey = @PatientKey,
            RoomKey = @RoomKey,
            TreatmentStartDateKey = @TreatmentStartDateKey,
            TreatmentEndDateKey = @TreatmentEndDateKey,
            TreatmentStartDate = @Treatment_Start_Date,
            TreatmentEndDate = @Treatment_End_Date,
            Age = @Age,
            Response = @Response,
            Description = @Description,
            TreatmentDuration = @TreatmentDuration
        WHERE RecordID = @Record_ID
    END
END;
GO

-- Stored Procedure for FactMedication
CREATE OR ALTER PROCEDURE dbo.InsertFactMedication
    @RecordKey INT,
    @MedicationKey INT,
    @PatientKey INT,
    @ParentKey INT,
    @EmployeeKey INT,
    @DateKey INT,
    @Quantity INT,
    @TotalCost FLOAT
AS
BEGIN
    -- Current timestamp
    DECLARE @CurrentTime DATETIME = GETDATE();
    
    -- Check if combination already exists
    IF NOT EXISTS (
        SELECT 1 FROM dbo.FactMedication 
        WHERE RecordKey = @RecordKey 
          AND MedicationKey = @MedicationKey
          AND PatientKey = @PatientKey
          AND ParentKey = @ParentKey
          AND EmployeeKey = @EmployeeKey
          AND DateKey = @DateKey
    )
    BEGIN
        INSERT INTO dbo.FactMedication
        (RecordKey, MedicationKey, PatientKey, ParentKey, EmployeeKey, DateKey, 
         Quantity, TotalCost, InsertDate, accm_txn_create_time)
        VALUES
        (@RecordKey, @MedicationKey, @PatientKey, @ParentKey, @EmployeeKey, @DateKey, 
         @Quantity, @TotalCost, @CurrentTime, @CurrentTime)
    END
    ELSE
    BEGIN
        -- Update existing record but do NOT update accm_txn_create_time
        UPDATE dbo.FactMedication
        SET Quantity = @Quantity,
            TotalCost = @TotalCost
        WHERE RecordKey = @RecordKey 
          AND MedicationKey = @MedicationKey
          AND PatientKey = @PatientKey
          AND ParentKey = @ParentKey
          AND EmployeeKey = @EmployeeKey
          AND DateKey = @DateKey
    END
END;
GO